from itertools import combinations

dots_tetr = {
    'A': (0,0,0),
    'B': (1,0,0),
    'C': (0,1,0),
    'D': (0,0,1)
}

P = (0,0,0)

def setPlane(p1, p2, p3):
    x1, y1, z1 = p1
    x2, y2, z2 = p2
    x3, y3, z3 = p3

    a1, a2, a3 = (x2 - x1, y2 - y1, z2 - z1)
    b1, b2, b3 = (x3 - x1, y3 - y1, z3 - z1)

    A = a2*b3 - a3*b2
    B = a3*b1 - a1*b3
    C = a1*b2 - a2*b1

    D = -(A*x1 + B*y1 + C*z1)
    return (A, B, C, D)

def insertDots(f, p):
    x, y, z = p
    A, B, C, D = f
    return A*x + B*y + C*z + D

def getOppositeDot(plane_keys):
    opposite_keys = set(dots_tetr.keys()) - set(plane_keys)
    return dots_tetr[list(opposite_keys)[0]]

def sign(x):
    if x > 0: return 1
    if x < 0: return -1
    return 0

state = []

def getEdge(key):
    if len(state)!=1:
        state.append(set(key))
    else:
        state.append(set(key))
        return list(set.intersection(*state))[0]+list(set.intersection(*state))[1]
    return False
    

def getVertex(key):
    if len(state)!=2:
        state.append(set(key))
    else:
        state.append(set(key))
        return list(set.intersection(*state))[0]
    return False

c = 0
results = {}

for plane_keys in combinations(dots_tetr.keys(), 3):
    p1, p2, p3 = (dots_tetr[k] for k in plane_keys)
    plane = setPlane(p1, p2, p3)
    opposite = getOppositeDot(plane_keys)

    signO = sign(insertDots(plane, opposite))
    signP = sign(insertDots(plane, P))

    if signP == 0:
        results[''.join(plane_keys)] = "на"
    elif signP == signO:
        c+=1
        results[''.join(plane_keys)] = "внутри"
    else:
        print("Точка лежит снаружи тетраэдэра")
        break

for key in results:
    if c == 4:
        print("точка лежит внутри тэтраэдэра")
        break
    if c==3 and results[key]=="на":
        print(f"точка лежит на плоскости {key}")
    elif c==2 and results[key]=="на":
        edge = getEdge(key)
        if edge!=False:
            print(f"точка лежит на ребре {edge}")
    elif c==1 and results[key]=="на":
        vertex = getVertex(key)
        if vertex!=False:
            print(f"точка лежит на вершине {vertex}")
