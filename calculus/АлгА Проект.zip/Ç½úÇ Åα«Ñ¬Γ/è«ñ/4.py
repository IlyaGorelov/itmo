import numpy as np

def point_in_tetrahedron(P, A, B, C, D, error_margin=1e-9):

    # матрица коэффициентов
    M = np.array([
        [A[0], B[0], C[0], D[0]],
        [A[1], B[1], C[1], D[1]],
        [A[2], B[2], C[2], D[2]],
        [1.0,  1.0,  1.0,  1.0 ]
    ])

    # правая часть
    rhs = np.array([P[0], P[1], P[2], 1.0])

    try:
        lambdas = np.linalg.solve(M, rhs)
    except:
        return "вырожденный тетраэдр"

    # если есть отрицательные — снаружи
    if any(l < -error_margin for l in lambdas):
        return "снаружи"

    # считаем нулевые
    zero_count = sum(abs(l) < error_margin for l in lambdas)

    if zero_count == 0:
        return "внутри"
    elif zero_count == 1:
        return "на грани"
    elif zero_count == 2:
        return "на ребре"
    elif zero_count == 3:
        return "на вершине"
    else:
        return "неопределено"
    
A = [0,0,0]
B = [1,0,0]
C = [0,1,0]
D = [0,0,1]

P=(0.25,0.25,0.25)
print(P)
print(point_in_tetrahedron(P,A,B,C,D))

P=(1/3,1/3,1/3)
print('(1/3, 1/3, 1/3)')
print(point_in_tetrahedron(P,A,B,C,D))

P=(0.2,0,0)
print(P)
print(point_in_tetrahedron(P,A,B,C,D))

P=(1,0,0)
print(P)
print(point_in_tetrahedron(P,A,B,C,D))

P=(0.5,0.5,0.5)
print(P)
print(point_in_tetrahedron(P,A,B,C,D))